
package profinal;
import java.util.Scanner;

public class ProFinal {

    
    public static void main(String[] args) {
        System.out.println("2do Avance Proyecto Final");
    }
    
}
